// lib/rego/types.ts
import type { AusState } from "./validate";
import type { DecodedVehicle } from "@/lib/vin/types";

export type RegoLookupSource =
  | "user_garage" // private cache from this user's own saved vehicles
  | "community_cache" // shared cache built from all users' rego→VIN submissions
  | "broker_api" // future: PARts / Redbook / NEVDIS broker
  | "manual"; // user typed VIN themselves after rego miss

export interface RegoLookupResult {
  ok: boolean;
  /** When ok=true and vehicle present, the lookup hit the cache or broker. */
  vehicle?: DecodedVehicle;
  /** When ok=true but no vehicle, ask the user to enter the VIN manually. */
  needsManualVin?: boolean;
  source?: RegoLookupSource;
  error?: string;
  warning?: string;
}

export interface RegoCacheEntry {
  rego: string;
  state: AusState;
  vin: string;
  /** How many independent users have confirmed this rego→VIN mapping. */
  confirmations: number;
  lastSeenAt: string;
  source: RegoLookupSource;
}
