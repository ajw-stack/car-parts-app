// lib/rego/lookup.ts
import { decodeVin } from "@/lib/vin/decode";
import { normaliseRego, validateRego, type AusState } from "./validate";
import type { RegoLookupResult } from "./types";

// ─────────────────────────────────────────────────────────────────────────────
// Cache layer — replace the in-memory stubs with your DB.
// Strategy:
//   1. user_garage   — private to this user (their saved vehicles)
//   2. community_cache — shared, built from ALL users' rego↔VIN pairings
//                        once we have ≥2 independent confirmations
//   3. broker_api    — future paid fallback (PARts / Redbook / NEVDIS)
// ─────────────────────────────────────────────────────────────────────────────

interface CacheLookupArgs {
  rego: string;
  state: AusState;
  userId: string | null;
}

interface CacheHit {
  vin: string;
  source: "user_garage" | "community_cache";
}

async function lookupUserGarage(
  _args: CacheLookupArgs,
): Promise<CacheHit | null> {
  // TODO: SELECT vin FROM garage_vehicles
  //       WHERE user_id = $userId AND rego = $rego AND rego_state = $state
  //       LIMIT 1;
  return null;
}

async function lookupCommunityCache(
  _args: CacheLookupArgs,
): Promise<CacheHit | null> {
  // TODO: SELECT vin FROM rego_vin_cache
  //       WHERE rego = $rego AND state = $state AND confirmations >= 2
  //       ORDER BY confirmations DESC, last_seen_at DESC LIMIT 1;
  //
  // Threshold of 2 = at least two independent users entered this rego with
  // the same VIN. Tune up to 3+ if you start seeing collisions.
  return null;
}

interface BrokerLookupResult {
  vin: string | null;
  error?: string;
}

async function lookupBroker(
  _args: CacheLookupArgs,
): Promise<BrokerLookupResult | null> {
  // TODO: integrate PARts or Redbook here.
  // Return null for now — disabled until broker contract is in place.
  //
  // Example shape when wired:
  //   const res = await fetch("https://api.parts.com.au/v1/rego", {
  //     method: "POST",
  //     headers: { Authorization: `Bearer ${process.env.PARTS_API_KEY}` },
  //     body: JSON.stringify({ rego, state }),
  //   });
  //   const data = await res.json();
  //   return { vin: data.vin };
  return null;
}

export async function lookupRego(
  rawRego: string,
  state: AusState,
  userId: string | null,
): Promise<RegoLookupResult> {
  const rego = normaliseRego(rawRego);
  const v = validateRego(rego, state);

  if (!v.ok) {
    const msg =
      v.reason === "empty"
        ? "Enter a rego."
        : v.reason === "invalid_chars"
          ? "Rego can only contain letters and numbers."
          : v.reason === "too_short"
            ? "Rego is too short."
            : "Rego is too long.";
    return { ok: false, error: msg };
  }

  const args = { rego, state, userId };

  // 1. Private cache first (fastest, free, most reliable for repeat lookups)
  if (userId) {
    const hit = await lookupUserGarage(args);
    if (hit) return await decodeAndWrap(hit.vin, "user_garage", v.warning);
  }

  // 2. Community cache (free, grows with your user base)
  const community = await lookupCommunityCache(args);
  if (community) {
    return await decodeAndWrap(community.vin, "community_cache", v.warning);
  }

  // 3. Broker (paid, not wired yet)
  const broker = await lookupBroker(args);
  if (broker?.vin) {
    return await decodeAndWrap(broker.vin, "broker_api", v.warning);
  }

  // 4. Miss — ask user to enter VIN manually. They become the seed for
  //    future community cache entries.
  return {
    ok: true,
    needsManualVin: true,
    warning: v.warning,
  };
}

async function decodeAndWrap(
  vin: string,
  source: RegoLookupResult["source"],
  warning?: string,
): Promise<RegoLookupResult> {
  const decoded = await decodeVin(vin);
  if (!decoded.ok || !decoded.vehicle) {
    return {
      ok: false,
      error: decoded.error ?? "Found a VIN for that rego but couldn't decode it.",
    };
  }
  return { ok: true, vehicle: decoded.vehicle, source, warning };
}

/**
 * Called when a user confirms their VIN after a rego miss (or saves a
 * vehicle to their garage with both rego and VIN). Builds the community
 * cache that powers future free lookups.
 */
export async function recordRegoVinPairing(_args: {
  rego: string;
  state: AusState;
  vin: string;
  userId: string;
}): Promise<void> {
  // TODO: INSERT INTO rego_vin_cache (rego, state, vin, confirmations,
  //          last_seen_at, first_user_id)
  //       VALUES ($rego, $state, $vin, 1, NOW(), $userId)
  //       ON CONFLICT (rego, state, vin) DO UPDATE SET
  //          confirmations = rego_vin_cache.confirmations + 1,
  //          last_seen_at = NOW()
  //       WHERE rego_vin_cache.first_user_id != $userId;
  //
  // Note the WHERE clause: only count distinct users. Same user re-saving
  // their own car shouldn't inflate confidence.
}
