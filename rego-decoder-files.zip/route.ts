// app/api/rego/lookup/route.ts
import { NextRequest, NextResponse } from "next/server";
import { lookupRego } from "@/lib/rego/lookup";
import { AUS_STATES, type AusState } from "@/lib/rego/validate";

export const runtime = "edge";

const VALID_STATES = new Set<AusState>(AUS_STATES.map((s) => s.code));

async function getUserId(_req: NextRequest): Promise<string | null> {
  // TODO: wire your auth (matches the stub in /api/garage/route.ts)
  return null;
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const rego = sp.get("rego");
  const state = sp.get("state") as AusState | null;

  if (!rego) {
    return NextResponse.json(
      { ok: false, error: "Missing rego param." },
      { status: 400 },
    );
  }
  if (!state || !VALID_STATES.has(state)) {
    return NextResponse.json(
      { ok: false, error: "Missing or invalid state. Use NSW/VIC/QLD/WA/SA/TAS/ACT/NT." },
      { status: 400 },
    );
  }

  const userId = await getUserId(req);
  const result = await lookupRego(rego, state, userId);
  return NextResponse.json(result, { status: result.ok ? 200 : 400 });
}
