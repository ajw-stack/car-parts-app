// app/api/rego/pairing/route.ts
//
// Called when a user confirms a VIN after a rego miss, or when saving a
// vehicle to their garage with both rego and VIN. This is what builds the
// community cache that powers future free lookups.

import { NextRequest, NextResponse } from "next/server";
import { recordRegoVinPairing } from "@/lib/rego/lookup";
import {
  AUS_STATES,
  normaliseRego,
  type AusState,
} from "@/lib/rego/validate";
import { normaliseVin, validateVin } from "@/lib/vin/validate";

const VALID_STATES = new Set<AusState>(AUS_STATES.map((s) => s.code));

async function getUserId(_req: NextRequest): Promise<string | null> {
  return null;
}

interface Body {
  rego?: string;
  state?: AusState;
  vin?: string;
}

export async function POST(req: NextRequest) {
  const userId = await getUserId(req);
  if (!userId) {
    return NextResponse.json(
      { ok: false, error: "Sign in to save vehicles." },
      { status: 401 },
    );
  }

  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return NextResponse.json(
      { ok: false, error: "Invalid body." },
      { status: 400 },
    );
  }

  const rego = body.rego ? normaliseRego(body.rego) : "";
  const vin = body.vin ? normaliseVin(body.vin) : "";

  if (!rego || !body.state || !VALID_STATES.has(body.state) || !vin) {
    return NextResponse.json(
      { ok: false, error: "Need rego, state, and vin." },
      { status: 400 },
    );
  }

  const v = validateVin(vin);
  if (!v.ok) {
    return NextResponse.json(
      { ok: false, error: "Invalid VIN." },
      { status: 400 },
    );
  }

  await recordRegoVinPairing({ rego, state: body.state, vin, userId });
  return NextResponse.json({ ok: true });
}
