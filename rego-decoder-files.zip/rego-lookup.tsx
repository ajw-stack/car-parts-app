"use client";

// components/rego-lookup.tsx
import { useState, useTransition } from "react";
import type { DecodedVehicle } from "@/lib/vin/types";
import type { RegoLookupResult } from "@/lib/rego/types";
import { AUS_STATES, type AusState } from "@/lib/rego/validate";
import { VinDecoder } from "./vin-decoder";

interface Props {
  defaultState?: AusState;
  onResolved?: (vehicle: DecodedVehicle, ctx: { rego: string; state: AusState }) => void;
}

export function RegoLookup({ defaultState = "VIC", onResolved }: Props) {
  const [rego, setRego] = useState("");
  const [state, setState] = useState<AusState>(defaultState);
  const [loading, startLookup] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [warning, setWarning] = useState<string | null>(null);
  const [vehicle, setVehicle] = useState<DecodedVehicle | null>(null);
  const [needsVin, setNeedsVin] = useState(false);
  const [source, setSource] = useState<RegoLookupResult["source"] | null>(null);

  const handleLookup = () => {
    setError(null);
    setWarning(null);
    setVehicle(null);
    setNeedsVin(false);
    setSource(null);

    startLookup(async () => {
      const url = `/api/rego/lookup?rego=${encodeURIComponent(rego)}&state=${state}`;
      const res = await fetch(url);
      const data = (await res.json()) as RegoLookupResult;

      if (!data.ok) {
        setError(data.error ?? "Lookup failed.");
        return;
      }
      if (data.warning) setWarning(data.warning);
      if (data.vehicle) {
        setVehicle(data.vehicle);
        setSource(data.source ?? null);
        onResolved?.(data.vehicle, { rego, state });
        return;
      }
      if (data.needsManualVin) setNeedsVin(true);
    });
  };

  // After a miss, the user enters a VIN. We capture it so the rego↔VIN
  // pairing can seed the community cache for future users.
  const handleVinSaved = async (v: DecodedVehicle) => {
    onResolved?.(v, { rego, state });
    try {
      await fetch("/api/rego/pairing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rego, state, vin: v.vin }),
      });
    } catch {
      // Pairing is best-effort; don't fail the user flow if it doesn't record.
    }
  };

  return (
    <div className="w-full max-w-xl space-y-4">
      <div>
        <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-200">
          Rego
        </label>
        <div className="mt-1 grid grid-cols-[1fr_auto_auto] gap-2">
          <input
            value={rego}
            onChange={(e) => setRego(e.target.value.toUpperCase())}
            onKeyDown={(e) => e.key === "Enter" && handleLookup()}
            placeholder="e.g. 1AB2CD"
            maxLength={7}
            spellCheck={false}
            autoComplete="off"
            className="rounded-md border border-zinc-300 bg-white px-3 py-2 font-mono tracking-wider text-sm uppercase focus:border-zinc-900 focus:outline-none focus:ring-1 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
          />
          <select
            value={state}
            onChange={(e) => setState(e.target.value as AusState)}
            className="rounded-md border border-zinc-300 bg-white px-2 py-2 text-sm focus:border-zinc-900 focus:outline-none focus:ring-1 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
            aria-label="State"
          >
            {AUS_STATES.map((s) => (
              <option key={s.code} value={s.code}>
                {s.code}
              </option>
            ))}
          </select>
          <button
            onClick={handleLookup}
            disabled={loading || !rego}
            className="rounded-md bg-zinc-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50 hover:bg-zinc-800 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-zinc-200"
          >
            {loading ? "…" : "Look up"}
          </button>
        </div>
      </div>

      {warning && (
        <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-200">
          {warning}
        </div>
      )}

      {error && (
        <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 dark:border-red-900 dark:bg-red-950 dark:text-red-200">
          {error}
        </div>
      )}

      {vehicle && (
        <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 dark:border-emerald-900 dark:bg-emerald-950/40">
          <p className="text-xs uppercase tracking-wide text-emerald-700 dark:text-emerald-300">
            Found via {sourceLabel(source)}
          </p>
          <h3 className="mt-1 text-lg font-semibold tracking-tight">
            {[vehicle.year, vehicle.make, vehicle.model].filter(Boolean).join(" ")}
          </h3>
          {vehicle.trim && (
            <p className="text-sm text-zinc-600 dark:text-zinc-400">
              {vehicle.trim}
            </p>
          )}
          <p className="mt-2 font-mono text-xs text-zinc-500">
            VIN: {vehicle.vin}
          </p>
        </div>
      )}

      {needsVin && (
        <div className="space-y-3 rounded-lg border border-zinc-200 bg-zinc-50 p-4 dark:border-zinc-800 dark:bg-zinc-900/50">
          <div>
            <p className="text-sm font-medium">
              We couldn't find {rego} ({state}) in our records yet.
            </p>
            <p className="mt-1 text-xs text-zinc-500">
              Enter the VIN to add this vehicle. You'll help future lookups of
              this rego work instantly.
            </p>
          </div>
          <VinDecoder onSaved={handleVinSaved} />
        </div>
      )}
    </div>
  );
}

function sourceLabel(s: RegoLookupResult["source"] | null): string {
  switch (s) {
    case "user_garage":
      return "your garage";
    case "community_cache":
      return "community records";
    case "broker_api":
      return "official records";
    case "manual":
      return "manual entry";
    default:
      return "lookup";
  }
}
