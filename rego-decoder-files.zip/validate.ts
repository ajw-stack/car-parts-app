// lib/rego/validate.ts
//
// Australian rego plate format validation, per state/territory.
//
// IMPORTANT: These patterns cover STANDARD-issue plates only. Australia has
// thousands of personalised, custom, club, heritage, and historic plate
// variants that won't match these patterns but ARE legitimate. We treat
// failed pattern matches as a soft warning, not a hard reject — the user
// might still have a valid plate we don't recognise.
//
// Sources: each state's road authority publishes plate format specs
// (VicRoads, Service NSW, etc.). These regex are the common-issue formats
// as of 2024 — they evolve as states roll new series.

export type AusState =
  | "NSW"
  | "VIC"
  | "QLD"
  | "WA"
  | "SA"
  | "TAS"
  | "ACT"
  | "NT";

export const AUS_STATES: { code: AusState; label: string }[] = [
  { code: "NSW", label: "New South Wales" },
  { code: "VIC", label: "Victoria" },
  { code: "QLD", label: "Queensland" },
  { code: "WA", label: "Western Australia" },
  { code: "SA", label: "South Australia" },
  { code: "TAS", label: "Tasmania" },
  { code: "ACT", label: "Australian Capital Territory" },
  { code: "NT", label: "Northern Territory" },
];

/**
 * Standard-issue patterns. Personalised plates are deliberately not covered
 * — they're free-form and we accept them as a warning rather than rejection.
 */
const STANDARD_PATTERNS: Record<AusState, RegExp[]> = {
  // NSW: current "ABC-12D" series + legacy "ABC-123" + numeric "12-AB-34"
  NSW: [/^[A-Z]{3}[0-9]{2}[A-Z]$/, /^[A-Z]{3}[0-9]{3}$/, /^[0-9]{2}[A-Z]{2}[0-9]{2}$/],
  // VIC: current "1AB-2CD" + legacy "ABC-123"
  VIC: [/^[0-9][A-Z]{2}[0-9][A-Z]{2}$/, /^[A-Z]{3}[0-9]{3}$/],
  // QLD: current "123-AB4" + legacy "123-ABC"
  QLD: [/^[0-9]{3}[A-Z]{2}[0-9]$/, /^[0-9]{3}[A-Z]{3}$/],
  // WA: "1ABC-234" / "1ABC234"
  WA: [/^[0-9][A-Z]{3}[0-9]{3}$/],
  // SA: "S123-ABC" current + legacy "ABC-123"
  SA: [/^S[0-9]{3}[A-Z]{3}$/, /^[A-Z]{3}[0-9]{3}$/],
  // TAS: "A12-BC3" current + legacy "ABC-123"
  TAS: [/^[A-Z][0-9]{2}[A-Z]{2}[0-9]$/, /^[A-Z]{3}[0-9]{3}$/],
  // ACT: "YAB-12C" / "ABC-12D" + legacy "ABC-123"
  ACT: [/^[A-Z]{3}[0-9]{2}[A-Z]$/, /^[A-Z]{3}[0-9]{3}$/],
  // NT: "CA-12-BC" + legacy "123-456"
  NT: [/^[A-Z]{2}[0-9]{2}[A-Z]{2}$/, /^[0-9]{3}[0-9]{3}$/, /^[A-Z]{3}[0-9]{2}$/],
};

export interface RegoValidationResult {
  ok: boolean;
  reason?: "empty" | "too_short" | "too_long" | "invalid_chars";
  warning?: string;
}

export function normaliseRego(input: string): string {
  return input.trim().toUpperCase().replace(/[\s\-·•]/g, "");
}

export function validateRego(
  raw: string,
  state: AusState,
): RegoValidationResult {
  const rego = normaliseRego(raw);

  if (!rego) return { ok: false, reason: "empty" };
  if (rego.length < 2) return { ok: false, reason: "too_short" };
  if (rego.length > 7) return { ok: false, reason: "too_long" };
  if (!/^[A-Z0-9]+$/.test(rego)) return { ok: false, reason: "invalid_chars" };

  const matchesStandard = STANDARD_PATTERNS[state].some((re) => re.test(rego));

  if (!matchesStandard) {
    // Soft pass — could be personalised / custom / heritage / club plate
    return {
      ok: true,
      warning:
        `"${rego}" doesn't match a standard ${state} plate format. ` +
        `If it's a personalised or custom plate, that's fine — we'll still try to look it up.`,
    };
  }

  return { ok: true };
}
