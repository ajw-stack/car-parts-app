// app/api/garage/route.ts
import { NextRequest, NextResponse } from "next/server";
import type { DecodedVehicle, GarageVehicle } from "@/lib/vin/types";

// ─────────────────────────────────────────────────────────────────────────────
// TODO: wire to your DB + auth. Examples below for Supabase / Prisma.
// Replace `getUserId` and the storage block.
// ─────────────────────────────────────────────────────────────────────────────

async function getUserId(_req: NextRequest): Promise<string | null> {
  // Supabase example:
  //   const supa = createServerClient(...);
  //   const { data: { user } } = await supa.auth.getUser();
  //   return user?.id ?? null;
  return null;
}

interface SavePayload {
  vehicle: DecodedVehicle;
  nickname?: string;
  rego?: string;
  rego_state?: string;
}

export async function POST(req: NextRequest) {
  const userId = await getUserId(req);
  if (!userId) {
    return NextResponse.json(
      { ok: false, error: "Not signed in." },
      { status: 401 },
    );
  }

  let body: SavePayload;
  try {
    body = (await req.json()) as SavePayload;
  } catch {
    return NextResponse.json(
      { ok: false, error: "Invalid body." },
      { status: 400 },
    );
  }

  if (!body?.vehicle?.vin) {
    return NextResponse.json(
      { ok: false, error: "Missing vehicle." },
      { status: 400 },
    );
  }

  // TODO: insert into your `garage_vehicles` table (uniqueness on user_id+vin).
  //
  // Supabase:
  //   const { data, error } = await supa.from("garage_vehicles").upsert({
  //     user_id: userId, vin: body.vehicle.vin, payload: body.vehicle,
  //     nickname: body.nickname, rego: body.rego, rego_state: body.rego_state,
  //   }, { onConflict: "user_id,vin" }).select().single();
  //
  // Prisma:
  //   const saved = await prisma.garageVehicle.upsert({ ... });

  const saved: GarageVehicle = {
    ...body.vehicle,
    id: crypto.randomUUID(),
    userId,
    nickname: body.nickname ?? null,
    rego: body.rego ?? null,
    rego_state: body.rego_state ?? null,
    createdAt: new Date().toISOString(),
  };

  return NextResponse.json({ ok: true, vehicle: saved });
}
