// app/api/vin/decode/route.ts
import { NextRequest, NextResponse } from "next/server";
import { decodeVin } from "@/lib/vin/decode";

export const runtime = "edge"; // fast, cheap on Vercel

export async function GET(req: NextRequest) {
  const vin = req.nextUrl.searchParams.get("vin");
  if (!vin) {
    return NextResponse.json(
      { ok: false, error: "Missing vin param." },
      { status: 400 },
    );
  }
  const result = await decodeVin(vin);
  return NextResponse.json(result, { status: result.ok ? 200 : 400 });
}
