// lib/vin/decode.ts
import type { DecodedVehicle, DecodeResult } from "./types";
import { normaliseVin, validateVin } from "./validate";

const NHTSA_URL =
  "https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValuesExtended";

/**
 * NHTSA returns flat key/value records via DecodeVinValuesExtended.
 * Empty strings are common — we map them to null and compute a confidence
 * score based on how many "core" fields came back populated.
 */
interface NhtsaRow {
  [key: string]: string;
}

const CORE_FIELDS = [
  "Make",
  "Model",
  "ModelYear",
  "BodyClass",
  "EngineCylinders",
  "FuelTypePrimary",
] as const;

function clean(v: string | undefined | null): string | null {
  if (v == null) return null;
  const t = v.trim();
  if (!t || t === "Not Applicable" || t === "0") return null;
  return t;
}

function scoreConfidence(row: NhtsaRow): "high" | "partial" | "low" {
  const filled = CORE_FIELDS.filter((f) => clean(row[f])).length;
  if (filled >= 5) return "high";
  if (filled >= 3) return "partial";
  return "low";
}

export async function decodeVin(rawVin: string): Promise<DecodeResult> {
  const vin = normaliseVin(rawVin);
  const v = validateVin(vin);
  if (!v.ok) {
    const msg =
      v.reason === "length"
        ? "VIN must be 17 characters."
        : v.reason === "invalid_chars"
          ? "VIN contains invalid characters (I, O, Q not allowed)."
          : "Invalid VIN.";
    return { ok: false, error: msg };
  }

  let res: Response;
  try {
    res = await fetch(`${NHTSA_URL}/${vin}?format=json`, {
      // 10s timeout via AbortSignal
      signal: AbortSignal.timeout(10_000),
      headers: { Accept: "application/json" },
      next: { revalidate: 60 * 60 * 24 * 30 }, // cache 30d — VIN data is immutable
    });
  } catch (e) {
    return { ok: false, error: "Decode service unreachable. Try again." };
  }

  if (!res.ok) {
    return { ok: false, error: `Decode service error (${res.status}).` };
  }

  const json = (await res.json()) as { Results?: NhtsaRow[] };
  const row = json.Results?.[0];
  if (!row) return { ok: false, error: "No data returned for this VIN." };

  // ErrorCode "0" = success. Anything else = warnings/errors. Surface but
  // don't necessarily fail — partial data is still useful.
  const errorCode = clean(row.ErrorCode);
  const errorText = clean(row.ErrorText);
  const fatal = errorCode && !errorCode.split(",").includes("0");

  const confidence = scoreConfidence(row);
  if (fatal && confidence === "low") {
    return {
      ok: false,
      error: errorText || "Could not decode this VIN.",
    };
  }

  const vehicle: DecodedVehicle = {
    vin,
    year: clean(row.ModelYear) ? Number(row.ModelYear) : null,
    make: clean(row.Make),
    model: clean(row.Model),
    trim: clean(row.Trim) || clean(row.Series),
    bodyClass: clean(row.BodyClass),
    engineCylinders: clean(row.EngineCylinders),
    engineDisplacementL: clean(row.DisplacementL),
    fuelType: clean(row.FuelTypePrimary),
    transmission: clean(row.TransmissionStyle),
    driveType: clean(row.DriveType),
    manufacturer: clean(row.Manufacturer),
    plantCountry: clean(row.PlantCountry),
    source: "nhtsa",
    confidence,
    rawErrors: fatal ? errorText : null,
  };

  // FUTURE: enrich with paid AU source (Redbook/DataOne) when confidence < high
  // and plantCountry === "AUSTRALIA" or make is AU-delivered.
  // const enriched = await enrichWithRedbook(vehicle);

  return { ok: true, vehicle };
}
