"use client";

// components/vin-decoder.tsx
import { useState, useTransition } from "react";
import type { DecodedVehicle, DecodeResult } from "@/lib/vin/types";

interface Props {
  /** Called after successful save. Useful for toast/redirect. */
  onSaved?: (v: DecodedVehicle) => void;
  /** Hide the "Save to My Garage" button, e.g. for guest users. */
  enableSave?: boolean;
}

export function VinDecoder({ onSaved, enableSave = true }: Props) {
  const [vin, setVin] = useState("");
  const [nickname, setNickname] = useState("");
  const [vehicle, setVehicle] = useState<DecodedVehicle | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saving, startSave] = useTransition();
  const [decoding, startDecode] = useTransition();
  const [saved, setSaved] = useState(false);

  const handleDecode = () => {
    setError(null);
    setVehicle(null);
    setSaved(false);
    startDecode(async () => {
      const res = await fetch(
        `/api/vin/decode?vin=${encodeURIComponent(vin)}`,
      );
      const data = (await res.json()) as DecodeResult;
      if (!data.ok || !data.vehicle) {
        setError(data.error ?? "Decode failed.");
        return;
      }
      setVehicle(data.vehicle);
    });
  };

  const handleSave = () => {
    if (!vehicle) return;
    startSave(async () => {
      const res = await fetch("/api/garage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ vehicle, nickname: nickname || undefined }),
      });
      const data = await res.json();
      if (!data.ok) {
        setError(data.error ?? "Save failed.");
        return;
      }
      setSaved(true);
      onSaved?.(vehicle);
    });
  };

  return (
    <div className="w-full max-w-xl space-y-4">
      <div>
        <label
          htmlFor="vin"
          className="block text-sm font-medium text-zinc-700 dark:text-zinc-200"
        >
          VIN
        </label>
        <div className="mt-1 flex gap-2">
          <input
            id="vin"
            value={vin}
            onChange={(e) => setVin(e.target.value.toUpperCase())}
            onKeyDown={(e) => e.key === "Enter" && handleDecode()}
            placeholder="17-character VIN"
            maxLength={17}
            spellCheck={false}
            autoComplete="off"
            className="flex-1 rounded-md border border-zinc-300 bg-white px-3 py-2 font-mono tracking-wider text-sm uppercase focus:border-zinc-900 focus:outline-none focus:ring-1 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
          />
          <button
            onClick={handleDecode}
            disabled={decoding || vin.length !== 17}
            className="rounded-md bg-zinc-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50 hover:bg-zinc-800 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-zinc-200"
          >
            {decoding ? "Decoding…" : "Decode"}
          </button>
        </div>
        <p className="mt-1 text-xs text-zinc-500">
          {vin.length}/17 — letters I, O, Q not allowed
        </p>
      </div>

      {error && (
        <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 dark:border-red-900 dark:bg-red-950 dark:text-red-200">
          {error}
        </div>
      )}

      {vehicle && (
        <div className="space-y-3 rounded-lg border border-zinc-200 bg-zinc-50 p-4 dark:border-zinc-800 dark:bg-zinc-900/50">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-lg font-semibold tracking-tight">
                {[vehicle.year, vehicle.make, vehicle.model]
                  .filter(Boolean)
                  .join(" ")}
              </h3>
              {vehicle.trim && (
                <p className="text-sm text-zinc-500">{vehicle.trim}</p>
              )}
            </div>
            <ConfidenceBadge level={vehicle.confidence} />
          </div>

          <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            <Field label="Body" value={vehicle.bodyClass} />
            <Field
              label="Engine"
              value={
                [
                  vehicle.engineDisplacementL &&
                    `${vehicle.engineDisplacementL}L`,
                  vehicle.engineCylinders &&
                    `${vehicle.engineCylinders}-cyl`,
                ]
                  .filter(Boolean)
                  .join(" ") || null
              }
            />
            <Field label="Fuel" value={vehicle.fuelType} />
            <Field label="Drive" value={vehicle.driveType} />
            <Field label="Transmission" value={vehicle.transmission} />
            <Field label="Plant" value={vehicle.plantCountry} />
          </dl>

          {vehicle.confidence !== "high" && (
            <p className="text-xs text-amber-700 dark:text-amber-300">
              Some fields couldn't be decoded from this VIN. Common for
              older or AU-delivered vehicles — we'll add an enrichment
              source soon.
            </p>
          )}

          {enableSave && (
            <div className="flex flex-col gap-2 border-t border-zinc-200 pt-3 dark:border-zinc-800 sm:flex-row">
              <input
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder="Nickname (optional, e.g. 'Daily ute')"
                className="flex-1 rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm focus:border-zinc-900 focus:outline-none focus:ring-1 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900"
              />
              <button
                onClick={handleSave}
                disabled={saving || saved}
                className="rounded-md border border-zinc-900 px-4 py-2 text-sm font-medium text-zinc-900 disabled:opacity-50 hover:bg-zinc-900 hover:text-white dark:border-zinc-100 dark:text-zinc-100 dark:hover:bg-zinc-100 dark:hover:text-zinc-900"
              >
                {saved ? "Saved ✓" : saving ? "Saving…" : "Save to My Garage"}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string; value: string | null }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-zinc-500">
        {label}
      </dt>
      <dd className="text-zinc-900 dark:text-zinc-100">
        {value ?? <span className="text-zinc-400">—</span>}
      </dd>
    </div>
  );
}

function ConfidenceBadge({
  level,
}: {
  level: "high" | "partial" | "low";
}) {
  const styles = {
    high: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200",
    partial:
      "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200",
    low: "bg-zinc-200 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300",
  }[level];
  return (
    <span
      className={`shrink-0 rounded-full px-2 py-0.5 text-xs font-medium ${styles}`}
    >
      {level} confidence
    </span>
  );
}
